#include<iostream>
#include"BigDecimalInt.h"
#include<string>
using namespace std;

bool BigDecimalInt::get_the_bigger(BigDecimalInt obj1,BigDecimalInt obj2)
{
    //to find which value is the bigger one
    if(obj1.sorted_number.length()==obj2.sorted_number.length())
    {
        for(int i=0;i<obj1.sorted_number.length();i++)
        {
            if(obj1.sorted_number[i]>obj2.sorted_number[i])
            {
                return true;
            }
            else if(obj1.sorted_number[i]<obj2.sorted_number[i])
            {
                return false;
            }
        }
    }
    else if(obj1.sorted_number.length()>obj2.sorted_number.length())
    {
        return true;
    }
    else
    {
        return false;
    }
}
//*********************
// to check if the values is equal or not
bool BigDecimalInt::equal_operator(BigDecimalInt obj1,BigDecimalInt obj2)
{
    if(obj1.sorted_number.length()==obj2.sorted_number.length())
    {
        for(int i=0;i<obj1.sorted_number.length();i++)
        {
            if(obj1.sorted_number[i]==obj2.sorted_number[i])
            {
                continue;
            }
            else
            {
                return false;
            }
        }
        return true;
    }
    else
    {
        return false;
    }
}
//*********************
// to remove zeros in the subtraction
void remove_zeros(string &zeros)
{
    if (zeros[0]=='0')
    {
        int i=0;
        while (zeros[i]=='0')
           {
               i++;
           }
        if (i==(zeros.length()))
            zeros.erase(0,i-1);
       else
            zeros.erase(0,i);
    }
   else if (zeros[0]=='-'&&zeros[1]=='0')
    {
       int i=0;
       while (zeros[i+1]=='0')
            {
                i++;
            }
        if (i==zeros.length())
            zeros.erase(1,i-1);
       else
            zeros.erase(1,i);
    }
}
//*********************
// to modify the sign to change it
int BigDecimalInt::modify_sign(BigDecimalInt &obj)
{
    string obj2;
    if(obj.sorted_number[0]=='-')
    {
        for(int i=1;i<obj.sorted_number.length();i++)
        {
            obj2+=obj.sorted_number[i];
        }
    obj.sorted_number=obj2;
    return 1;
    }
    else if(obj.sorted_number[0]=='+')
    {
        for(int i=1;i<obj.sorted_number.length();i++)
        {
            obj2+=obj.sorted_number[i];
        }
      obj.sorted_number=obj2;
      return 0;
    }
    else
    {
        return 0;
    }
}
void BigDecimalInt::reverse_operator(string &number)
{
    //to but values in reverse
    string m="";
    m=number;
    int j=number.length()-1;
    for(int i=0;i<number.length();i++)
    {
        number[i]=m[j];
        j--;
    }

}
//*********************
// assignment operator to put the value from this attribute to another one
BigDecimalInt BigDecimalInt::operator=(BigDecimalInt obj2)
{
    sorted_number=obj2.sorted_number;
    return *this;
}
//*********************
//operator overloading to print
ostream &operator <<(ostream &output,BigDecimalInt &obj)
{
    output<<obj.sorted_number;
    return output;
}
//********************
//default constructor
BigDecimalInt::BigDecimalInt()
{
    sorted_number="";
}
//******************
// the parameterise constructor with string
BigDecimalInt::BigDecimalInt(string decStr)
{
    sorted_number=decStr;
}
//*****************
//the parameterise constructor with integer
BigDecimalInt::BigDecimalInt (int decInt)
{
    if(decInt>0)
    {
    while(decInt!=0)
    {
    sorted_number+=decInt%10+'0';
    decInt-=decInt%10;
    decInt/=10;
    }
    reverse_operator(sorted_number);
    }
    else if(decInt<0)
    {
    decInt*=-1;
    while(decInt!=0)
    {
    sorted_number+=decInt%10+'0';
    decInt-=decInt%10;
    decInt/=10;
    }
    sorted_number+='-';
    reverse_operator(sorted_number);
    }
    else
    {
     sorted_number="0";
    }
}
//*********************
//to calculate if the number is addition to another number
BigDecimalInt BigDecimalInt::operator+(BigDecimalInt obj)
{
    if(sorted_number[0]=='-'&&((obj.sorted_number[0]>='0'&&obj.sorted_number[0]<='9')||obj.sorted_number[0]=='+'))
    {
        modify_sign(*this);
        modify_sign(obj);
        return obj-(*this);
    }
    if(obj.sorted_number[0]=='-'&&((sorted_number[0]>='0'&&sorted_number[0]<='9')||sorted_number[0]=='+'))
    {
        modify_sign(obj);
        modify_sign(*this);
        return (*this)-obj;
    }
    if(obj.sorted_number.length()>sorted_number.length())
    {
        int difference = obj.sorted_number.length()-sorted_number.length();
        bool check_sign(modify_sign(obj)&&modify_sign(*this));
        BigDecimalInt temb;
        temb.sorted_number="";
        temb.carry=0;
        for(int i=(sorted_number.length()-1);i>=0;i--)
        {
        temb.sum=0;
        temb.sum=sorted_number[i]+obj.sorted_number[i+difference]-2*'0'+temb.carry;
        temb.carry=0;
        if(temb.sum>9)
        {
            temb.sum-=10;
            temb.carry++;
        }
        temb.sorted_number+=temb.sum+'0';
        }
        for(int i=difference-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum+=obj.sorted_number[i]+temb.carry-'0';
            temb.carry=0;
            if(temb.sum>9)
            {
                temb.sum-=10;
                temb.carry++;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        if(temb.carry>0)
        {
            temb.sorted_number+=temb.carry+'0';
        }
        if(check_sign)
        {
            temb.sorted_number+='-';
        }
        reverse_operator(temb.sorted_number);
        return temb;
    }
    if(obj.sorted_number.length()<sorted_number.length())
    {
        int difference = sorted_number.length()-obj.sorted_number.length();
        bool check_sign(modify_sign(*this)&&modify_sign(obj));
        BigDecimalInt temb;
        temb.sorted_number="";
        temb.carry=0;
        for(int i=obj.sorted_number.length()-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum=sorted_number[i+difference]+obj.sorted_number[i]-2*'0'+temb.carry;
            temb.carry=0;
            if(temb.sum>9)
            {
                temb.sum-=10;
                temb.carry++;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        for(int i=difference-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum+=sorted_number[i]+temb.carry-'0';
            temb.carry=0;
            if(temb.sum>9)
            {
                temb.sum-=10;
                temb.carry++;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        if(temb.carry>0)
        {
            temb.sorted_number+=temb.carry+'0';
        }
        if(check_sign)
        {
            temb.sorted_number+='-';
        }
        reverse_operator(temb.sorted_number);
        return temb;
    }
    else
    {
        bool check_sign(modify_sign(*this)&&modify_sign(obj));
        BigDecimalInt temb;
        temb.carry=0;
        for(int i=sorted_number.length()-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum=sorted_number[i]+obj.sorted_number[i]-2*'0'+temb.carry;
            temb.carry=0;
            if(temb.sum>9)
            {
                temb.sum-=10;
                temb.carry++;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        if(temb.carry>0)
        {
            temb.sorted_number+=temb.carry+'0';
        }
        if(check_sign)
        {
            temb.sorted_number+='-';
        }
        reverse_operator(temb.sorted_number);
        return temb;
    }
}
//*******************************
//to make subtraction
BigDecimalInt BigDecimalInt::operator-(BigDecimalInt obj)
{
    if(sorted_number[0]=='-'&&((obj.sorted_number[0]>='0'&&obj.sorted_number[0]<='9')||obj.sorted_number[0]=='+'))
    {
        modify_sign(*this);
        modify_sign(obj);
        return *this+obj;
    }
    if(obj.sorted_number[0]=='-'&&((sorted_number[0]>='0'&&sorted_number[0]<='9')||sorted_number[0]=='+'))
    {
       modify_sign(obj);
       modify_sign(*this);
       return *this+obj;
    }
    if(obj.sorted_number[0]=='-'&&sorted_number[0]=='-')
    {
        modify_sign(*this);
        modify_sign(obj);
        return obj-*this;
    }
    if(sorted_number.length()>obj.sorted_number.length())
    {
        int difference = sorted_number.length()-obj.sorted_number.length();
        BigDecimalInt temb;
        temb.sum=0;
        temb.carry=0;
        for(int i=obj.sorted_number.length()-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum = sorted_number[i+difference]-obj.sorted_number[i]+temb.carry;
            temb.carry=0;
            if(temb.sum<0)
            {
               temb.sum+=10;
               temb.carry--;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        for(int i=difference-1;i>=0;i--)
        {
            temb.sum=0;
            temb.sum+=sorted_number[i]+temb.carry-'0';
            temb.carry=0;
            if(temb.sum<0)
            {
                temb.sum+=10;
                temb.carry--;
            }
            temb.sorted_number+=temb.sum+'0';
        }
        reverse_operator(temb.sorted_number);
        remove_zeros(temb.sorted_number);
        return temb;
    }
    if(sorted_number.length()<obj.sorted_number.length())
    {
       int difference = obj.sorted_number.length()-sorted_number.length();
       BigDecimalInt temb;
       temb.sorted_number="";
       temb.carry=0;
       for(int i=(sorted_number.length()-1);i>=0;i--)
       {
           temb.sum=0;
           temb.sum =obj.sorted_number[i+difference]-sorted_number[i]+temb.carry;
           temb.carry=0;
           if(temb.sum<0)
           {
               temb.sum+=10;
               temb.carry--;
           }
           temb.sorted_number+=temb.sum+'0';
       }
       for(int i=difference-1;i>=0;i--)
       {
           temb.sum=0;
           temb.sum+=obj.sorted_number[i]+temb.carry-'0';
           temb.carry=0;
           if(temb.sum<0)
           {
               temb.sum+=10;
               temb.carry--;
           }
           temb.sorted_number+=temb.sum+'0';
        }
        temb.sorted_number+='-';
        reverse_operator(temb.sorted_number);
        remove_zeros(temb.sorted_number);
        return temb;
    }
    else
    {
        if(equal_operator(*this,obj))
        {
            BigDecimalInt temb;
            temb.sorted_number="0";
            return temb;
        }
        else if(get_the_bigger(*this,obj))
        {
            BigDecimalInt temb;
            temb.sorted_number="";
            temb.carry=0;
            for (int i=(sorted_number.length()-1); i>=0; i--)
            {
                temb.sum=0;
                temb.sum=sorted_number[i]-obj.sorted_number[i]+temb.carry;
                temb.carry=0;
                if (temb.sum<0)
                {
                    temb.sum+=10;
                    temb.carry--;
                }
                temb.sorted_number+=temb.sum+'0';
            }
            reverse_operator(temb.sorted_number);
            remove_zeros(temb.sorted_number);
            return temb;
        }
        else if(get_the_bigger(obj,*this))
        {
            BigDecimalInt temb;
            temb.sorted_number="";
            temb.carry=0;
            for (int i=(obj.sorted_number.length()-1); i>=0; i--)
            {
                temb.sum=0;
                temb.sum=obj.sorted_number[i]-sorted_number[i]+temb.carry;
                temb.carry=0;
                if (temb.sum<0)
                {
                    temb.sum+=10;
                    temb.carry--;
                }
                temb.sorted_number+=temb.sum+'0';
            }
            temb.sorted_number+='-';
            reverse_operator(temb.sorted_number);
            remove_zeros(temb.sorted_number);
            return temb;
        }
    }
}
//*************************
//to print the size
int BigDecimalInt::size()
{
    return sorted_number.length();
}
