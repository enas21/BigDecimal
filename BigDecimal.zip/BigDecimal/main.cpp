#include <iostream>
#include <bits/stdc++.h>
#include <string>
#include "BigDecimalInt.h"
using namespace std;

int main()
{
char choice;
do{
string Number1,Number2;
cout<<"Welcome to FCI Calculator"<<endl;
cout<<"---------------------------------------- "<<endl;
cout<<"1- Perform Addition\n";
cout<<"2- Perform Subtraction\n";
cout<<"3- Exit\n ";
cin>>choice;

switch(choice)
{
    case '1':
        {
            cout<<"please , enter your first number : ";
            cin>>Number1;
            BigDecimalInt num1(Number1);
            cout<<"num1 = "<<Number1<<endl;
            cout<<"please , enter your second number : ";
            cin>>Number2;
            BigDecimalInt num2(Number2);
            cout<<"num2 = "<<Number2<<endl;
            BigDecimalInt num3 = num1 + num2;
            cout<<"num1 + num2="<<num3<<endl;
            break;
        }
    case '2':
        {
            cout<<"please , enter your first number : ";
            cin>>Number1;
            BigDecimalInt num1(Number1);
            cout<<"num1 = "<<Number1<<endl;
            cout<<"please , enter your second number : ";
            cin>>Number2;
            BigDecimalInt num2(Number2);
            cout<<"num2 = "<<Number2<<endl;
            BigDecimalInt num3 = num1 - num2;
            cout<<"num1 - num2="<<num3<<endl;
            break;
        }
    case '3':
        {
         break;
        }
    default :
        {
            cout<<"you have entered invalid number , please try again\n";
        }
    }
 }while(choice!='3');
    return 0;
}
