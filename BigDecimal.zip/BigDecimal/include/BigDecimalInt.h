#ifndef BIGDECIMALINT _H
#define BIGDECIMALINT _H
#include <iostream>
#include <bits/stdc++.h>
#include <string>
#include <string.h>
using namespace std;

class BigDecimalInt
{
    private:
        string sorted_number;
        int sum,carry;

    public:
        BigDecimalInt ();
        BigDecimalInt (string decStr);
        BigDecimalInt (int decInt);
        void reverse_operator(string &number);
        int modify_sign(BigDecimalInt &object);
        BigDecimalInt operator+(BigDecimalInt obj);
        BigDecimalInt operator-(BigDecimalInt obj);
        BigDecimalInt operator=(BigDecimalInt obj);
        friend ostream &operator <<(ostream &output,BigDecimalInt &obj);
        bool get_the_bigger(BigDecimalInt obj1,BigDecimalInt obj2);
        bool equal_operator(BigDecimalInt obj1,BigDecimalInt obj2);
        int size();
};

#endif // BIGDECIMALINT _H
